#AmadisFile.py

from pygame import *
from math import *
size=width,height=1200,800
screen=display.set_mode((1200,800))
RED=(255,0,0)   
GREEN=(0,255,0)
BLUE=(0,0,255)
BLACK=(0,0,0)
WHITE=(255,255,255)

deaths=0


frame=0
eFrame=0

font.init()
comicFont=font.SysFont("Comic Sans MS",28)
agencyFont=font.SysFont("Agency FB",28)

upkey=image.load("Images/upKey-removebg.png")
upkey=transform.scale(upkey,(50,50))
spacekey=image.load("Images/spacekey-removebg.png")
spacekey=transform.scale(spacekey,(100,50))
plat1=image.load("Images/plat1.jpg").convert()
plat1=transform.scale(plat1,(100,100))
plat2=image.load("Images/plat2.jpg").convert()
plat2=transform.scale(plat2,(100,40))
plat2s=transform.scale(plat2,(10,30))
plat1s=transform.scale(plat1,(20,20))



v=[2,0]
pressed=False
dpressed=False
alive=True
lev=1

rocks=[Rect(615,210,75,75),Rect(885,215,125,75)]
rocks2=[Rect(725,350,250,125),Rect(965,610,120,70)]
rocks3=[Rect(15,550,100,100),Rect(300,400,100,40),Rect(400,400,100,40),Rect(850,500,10,30),Rect(1000,250,100,40)]
rocks4=[Rect(200,200,20,20),Rect(35,600,10,30), Rect(320,370,100,40), Rect(500,200,10,30), Rect(650,700,10,30),Rect(1040,700,10,30)]
rocks5=[Rect(50,200,20,20)]

backPic=image.load("Images/Backmain1.5.png").convert()
backPic2=image.load("Images/Backmain2.png").convert()
backPic3=image.load("Images/Backgroundlev3.5.png").convert()
backPic4=image.load("Images/Backgroundlev3.75.png").convert()
backPic5=image.load("Images/Backgroundlev5.5.png").convert()


j=False
jcount=0
X=0
Y=1
VY=2
ONGROUND=3
bullets=[]
rapid=20

hero=[250,450,0,True]
enemy1=[500,150,0,True]
enemy2=[600,150,0,True]
enemy3=[700,150,0,True]

#gun=(hero[0]+30,hero[1]+20)

def moveBullet(bull):
    for b in bull:
        b[0]+=b[2]
        b[1]+=b[3]
        if b[0]>1200 or b[0]<0:
            bullets.remove(b) #removing off screen bullets

def distance(x1,y1,x2,y2):
    return sqrt((x1-x2)**2+(y1-y2)**2)

def checkHit(bull,targ):
    for b in bull:
        for t in targ:
            d=sqrt((b[0]-t[0])**2+(b[1]-t[1])**2)
            if d<44:
                targ.remove(t)
                bull.remove(b)

jump=0
def moveGuy(player):
    '''move guy will control the location of the player. It will also adjust
    the move and the frame variables to ensure the correct pic is drawn'''
    global move,frame,rapid,pressed,dpressed,jumps,jump,jcount,lev,deaths
    keys=key.get_pressed()

    newMove=-1
    if keys[K_RIGHT]:
        newMove=0
        player[0]+=4

    elif keys[K_LEFT]:
        newMove=3
        player[0]-=4
        
    else:
        frame=0
    if j:
        jcount+=1
        if jcount<15 and click:
            player[VY]=-10 #jumping power
            player[ONGROUND]=True



    player[Y]+=player[VY]


    if lev==1:
        if player[Y]>=350:
            player[Y]=350 #stay on the ground
            player[VY]=0 #stop falling
            player[ONGROUND]=True
            dpressed=False
            jump=0
            jcount=0
    if lev==2:
        if player[Y]>=350 and player[X]<420:
            player[Y]=350 #stay on the ground
            player[VY]=0 #stop falling
            player[ONGROUND]=True
            dpressed=False
            jump=0
            jcount=0
    if player[Y]>800:
        lev=1
        player[X],player[Y]=(50,350)
        deaths+=1
    
    if lev==3:
        if player[Y]>800:
            deaths+=1
            player[X],player[Y]=(20,350)

    if lev==4:
        if player[Y]>800:
            deaths+=1
            player[X],player[Y]=(20,350)

    if lev==5:
        if player[Y]>800:
            deaths+=1
            player[X],player[Y]=(20,350)
        
            
    player[VY]+=0.4 #apply gravity


    if move==newMove:
        frame=frame+0.2
        if frame>=len(pics[move]):
            frame=1
    elif newMove!=-1:
        move=newMove
        frame=1

    

    if keys[32] and rapid==20 and pressed==False:
        pressed=True
        rapid=0
   
        if move==0 and len(bullets)<=4:
            bullets.append([gun[0]+20,gun[1],10,0])
        elif move==3 and len(bullets)<=4:
            bullets.append([gun[0]-40,gun[1],-10,0])        

        
    if rapid<20:
        rapid+=20

def moveEnemy(enemy,player):
    global eMove,eFrame

    keys=key.get_pressed()
    eNewMove=-1
    eMove=0
    speed=1

    if player[Y]<enemy[Y] and enemy[ONGROUND]: 
        eNewMove=4
        enemy[2]=-15
        enemy[ONGROUND]=False

    if player[X]>enemy[X] and enemy[X]<=3000:
        eNewMove=0
        enemy[X]+=speed 

    elif keys[K_DOWN]:
        eNewMove=1
        enemy[Y]+=speed

    elif keys[K_UP]:
        eNewMove=2
        enemy[Y]-=speed

    elif player[X]<enemy[X]: 
        eNewMove=3
        enemy[X]-=speed

    elif enemy[ONGROUND] and move==4:
        eMove=3
        eFrame=3

    elif enemy[ONGROUND] and move==5:
        eMove=0
        eFrame=3

    else:
        speed=0
        eNewMove=5

    enemy[X]+=enemy[2]

    enemy[Y]+=0.4   

    if enemy[Y]>=400:
        enemy[Y]=400  
        enemy[3]=0   
        enemy[ONGROUND]=True

    else:
        eFrame=3      

    if eMove==eNewMove:
        eFrame=eFrame+0.2
        if eFrame>=len(ePics[eMove]):
            eFrame=1

    elif eNewMove!=-1:
        eMove=eNewMove
        eFrame=3

def distance(x1,y1,x2,y2):
    d=sqrt((x2-x1)**2+(y2-y1)**2)
    return d

def drawScene(screen,picList,player,enemy,bull,ePicList):
    global lev,frame,move
    rec=Rect(player[X],player[Y],29,65)
    if move==3:
        rec=Rect(player[X]+22,player[Y],29,65)        
    '''this function is displaying one of the 24 pictures in the 2D List'''
    txtPic=comicFont.render("Deaths: %s"%str(deaths),True,WHITE)
    inst=agencyFont.render("TO JUMP",True,BLACK)
    inst2=agencyFont.render("TO DOUBLE JUMP",True,BLACK)
    inst3=agencyFont.render("TO SHOOT",True,BLACK)
    

    if lev==1:
        screen.blit(backPic,(0,0))
        screen.blit(txtPic,(2,2))
        screen.blit(inst,(300,58))
        screen.blit(inst2,(520,58))
        screen.blit(upkey,(250,50))
        screen.blit(upkey,(420,50))
        screen.blit(upkey,(470,50))
        screen.blit(spacekey,(700,50))
        screen.blit(inst3,(800,58))
        draw.rect(screen,RED,rec)



        
    elif lev==2:
        
        screen.blit(backPic2,(0,0))
        screen.blit(txtPic,(2,2))
        draw.rect(screen,RED,rec)

    elif lev==3:
        screen.blit(backPic3,(0,0))
        screen.blit(plat1,(15,550))
        draw.rect(screen,RED,rec)
        screen.blit(txtPic,(2,2))
        screen.blit(plat2,(300,400))
        screen.blit(plat2,(400,400))
        screen.blit(plat2,(1000,250))
        screen.blit(plat1s,(850,500))
        

    elif lev==4:
        screen.blit(backPic4,(0,0))
        draw.rect(screen,RED,rec)
        screen.blit(txtPic,(2,2))
        screen.blit(plat1s,(35,600))
        screen.blit(plat2,(320,370))
        screen.blit(plat1s,(500,200))
        screen.blit(plat1s,(650,700))
        screen.blit(plat1s,(1040,700))

    elif lev==5:
        screen.blit(backPic5,(0,0))
        draw.rect(screen,RED,rec)
        screen.blit(txtPic,(2,2))
        screen.blit(plat1s,(50,200))
        
               
        
    if player[X]>1200 and lev==1:
        lev=2
        player[X]=50
    if player[X]<=0 and lev==2:
        lev=1
        player[X]=1195
    if player[X]<0 and lev==3:
        lev=2
        player[X],player[Y]=(1100,450)
    if player[X]>1200 and lev==2:
        lev=3
        player[X],player[Y]=(5,400)
    if player[X]>1200 and player[Y]<300 and lev==3:
        lev=4
        player[X],player[Y]=(10,300)
    if player[X]<0 and lev==4:
        lev=3
        player[X],player[Y]=(1150,200)
    if player[X]>1200 and lev==4:
        lev=5
        player[X],player[Y]=(20,100)
    
    try:
        pic=picList[move][int(frame)]
        ePic=ePicList[eMove][int(eFrame)]
        screen.blit(pic,(player[0],player[1]))
        screen.blit(ePic,(enemy[0],enemy[1]))
    except:
        pass
    
    
    for b in bull:
        draw.circle(screen,RED,(int(b[0]),int(b[1])),4)
    
        

def addPics(name,start,end):
    '''this function will return a list of pics. The pics must be in a folder
        named "name" and the pictures' names must start with "name"
        start,end - range of picture numbers'''
    myPics=[]
    for i in range(start,end+1):
        myPics.append(image.load("%s/%s%03d.png" %(name,name,i)))
    return myPics

def checkCollision(player,rock):
    global jump,jcount,fr ############################
    rec=Rect(player[X],player[Y],29,65)
    if move==3:
       rec=Rect(player[X]+22,player[Y],29,65) 
    if lev==1:        
        for r in rock:
            if rec.colliderect(r):
                if player[VY]>0 and rec.move(0,-player[VY]).colliderect(r)==False:
                    player[ONGROUND]=True
                    player[VY]=0
                    player[Y]=r.y-65
                    jump=0################
                    jcount=0############
    elif lev==2:
        for r in rock:
            if rec.colliderect(r):
                if player[VY]>0 and rec.move(0,-player[VY]).colliderect(r)==False:
                    player[ONGROUND]=True
                    player[VY]=0
                    player[Y]=r.y-65
                    jump=0################
                    jcount=0############

    elif lev==3:
        for r in rock:
            if rec.colliderect(r):
                if player[VY]>0 and rec.move(0,-player[VY]).colliderect(r)==False:
                    player[ONGROUND]=True
                    player[VY]=0
                    player[Y]=r.y-65
                    jump=0################
                    jcount=0############

    elif lev==4:
        for r in rock:
            if rec.colliderect(r):
                if player[VY]>0 and rec.move(0,-player[VY]).colliderect(r)==False:
                    player[ONGROUND]=True
                    player[VY]=0
                    player[Y]=r.y-65
                    jump=0################
                    jcount=0############

    elif lev==5:
        for r in rock:
            if rec.colliderect(r):
                if player[VY]>0 and rec.move(0,-player[VY]).colliderect(r)==False:
                    player[ONGROUND]=True
                    player[VY]=0
                    player[Y]=r.y-65
                    jump=0################
                    jcount=0############

                
    


move=0  #current move (the "row") (right-0,down-1,up-2,left-3)
frame=0 #current frame within the move (the "column")

pics=[] #2d list that will have all 24 pics (rows and 6 pics in each)
        #index 0 is the "idle" frame and 1-5 are the "walking" frames.
ePics=[]
pics.append(addPics("Hero",15,20)) #right
pics.append(addPics("Hero",21,23)) #down
pics.append(addPics("Hero",21,23)) #up
pics.append(addPics("Heroflipped",15,20)) #left
ePics.append(addPics("Enemies",1,5))
ePics.append(addPics("EnemiesFlipped",1,5))

myclock=time.Clock()
running=True
while running:
    for evt in event.get():
        if evt.type==QUIT:
            running=False
        if evt.type==KEYDOWN:
            click=True
            if evt.key==K_UP and click:                
                jump+=1
                if jump<=2:
                    j=True
                
        if evt.type==KEYUP:
            if evt.key==32:
                pressed=False
            if evt.key==K_UP:
                j=False
    
        
    
    
    moveGuy(hero)
    moveEnemy(enemy1,hero)
    moveEnemy(enemy2,hero)
    moveEnemy(enemy3,hero)

    gun=(hero[0]+35,hero[1]+20)
    if pics=="Heroflipped":
        x=0

    moveBullet(bullets)
##    checkHit(bullets,enemies)
    if lev==1:
        checkCollision(hero,rocks)
    elif lev==2:
        checkCollision(hero,rocks2)
    elif lev==3:
        checkCollision(hero,rocks3)
    elif lev==4:
        checkCollision(hero,rocks4)
    elif lev==5:
        checkCollision(hero,rocks5)
    drawScene(screen,pics,hero,enemy1,bullets,ePics)
    drawScene(screen,pics,hero,enemy2,bullets,ePics)
    drawScene(screen,pics,hero,enemy3,bullets,ePics)
    myclock.tick(60)
    click=False
    display.flip()
quit()      

